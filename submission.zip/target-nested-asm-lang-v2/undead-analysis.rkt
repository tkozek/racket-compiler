#lang racket

(require cpsc411/compiler-lib
         "../common.rkt")

(provide undead-analysis)

;; (asm-pred-lang-v8/locals p) -> (asm-pred-lang-v8/undead p)
;; Performs undeadness analysis, decorating the program with undead-set tree.
;; Only the info field of the program is modified.
(define (undead-analysis p)

  (define call-undead-box (box `()))

  (define (record-call-undead! s)
    (set-box!
     call-undead-box
     (set-subtract (set-union (unbox call-undead-box) s)
                   `(,(current-frame-base-pointer-register) ,(current-return-value-register)))
     ;(set-union (unbox call-undead-box) s)
     ))

  (define (analyze-definitions def)
    (match def
      [`(define ,label
          ,info
          ,tail)
       (set-box! call-undead-box `())
       `(define ,label
          ,(info-set (info-set info
                               'undead-out
                               (let-values ([(_ ust) (analyze-program-tail `() tail)])
                                 (first ust)))
                     'call-undead
                     (set->list (unbox call-undead-box)))
          ,tail)]))

  ;; undead-set (asm-lang-v2/locals effect) -> (values undead-set ust)
  ;; SLIGHTLY MODIFIED CODE FROM LECTURE
  ;; takes in the undead-out set for the current instruction
  ;; and computes the undead-in set for the current instruction,
  ;; and the undead-set-tree for the effect
  (define (analyze-program-effect undead-out effect)
    (match effect
      [`(begin
          ,effects ...
          ,effect)
       (let-values ([(undead-out updated-ust) (analyze-program-effect undead-out effect)])
         (let-values ([(pre-wrap-undead-out pre-wrap-updated-ust)
                       (for/foldr ([undead-out undead-out] [ust `(,updated-ust)])
                                  ([effect effects])
                                  (let-values ([(undead-in new-ust) (analyze-program-effect undead-out
                                                                                            effect)])
                                    (values undead-in (cons new-ust ust))))])

           ;(values pre-wrap-undead-out `(,pre-wrap-updated-ust))
           (values pre-wrap-undead-out pre-wrap-updated-ust)))]
      [`(set! ,loc1 (mref ,loc2 ,index))
        (let ([undead-in
                (set-add-triv
                  (set-add
                    (set-remove undead-out loc1)
                    loc2)
                  index)])
          (values undead-in undead-out))]
      [`(mset! ,loc ,index ,triv)
        (let ([undead-in
                (set-add-triv
                  (set-add-triv
                    (set-add undead-out loc)
                    index)
                  triv)])
          (values undead-in undead-out))]
      [`(set! ,aloc_1 (,binop ,aloc_1 ,triv))
       (let ([undead-in (set-add (set-add-triv undead-out triv) aloc_1)])
         (values undead-in undead-out))]
      [`(set! ,aloc ,triv)
       (let ([undead-in (set-add-triv (set-remove undead-out aloc) triv)])
         (values undead-in undead-out))]
      [`(if ,pred ,effect1 ,effect2)
       (let*-values ([(undead-out-effect2 ust-effect2) (analyze-program-effect undead-out effect2)]
                     [(undead-out-effect1 ust-effect1) (analyze-program-effect undead-out effect1)]
                     [(undead-out-pred ust-pred)
                      (analyze-program-pred (set-union undead-out-effect1 undead-out-effect2) pred)])
         (values undead-out-pred `(,ust-pred ,ust-effect1 ,ust-effect2)))]
      [`(return-point ,label ,tail)
       (let-values ([(undead-in ust-tail) (analyze-program-tail undead-out tail)])
         (record-call-undead! undead-out)
         (values (set-union (set-remove undead-out (current-return-value-register)) undead-in)
                 `(,undead-out ,(first ust-tail))))]))

  (define (analyze-program-pred undead-out pred)
    (match pred
      [`(,relop ,aloc ,triv)
       #:when (memq relop '(< <= = >= > !=))
       (let ([undead-in (set-add-triv (set-add undead-out aloc) triv)])
         (values undead-in undead-out))]
      [`(true) (values undead-out undead-out)]
      [`(false) (values undead-out undead-out)]
      [`(not ,pred)
       (let-values ([(undead-out-pred updated-ust) (analyze-program-pred undead-out pred)])
         (values undead-out-pred updated-ust))]
      [`(begin
          ,effects ...
          ,pred)
       (let-values ([(undead-out updated-ust) (analyze-program-pred undead-out pred)])
         (let-values ([(pre-wrap-undead-out pre-wrap-updated-ust)
                       (for/foldr ([undead-out undead-out] [ust `(,updated-ust)])
                                  ([effect effects])
                                  (let-values ([(undead-in new-ust) (analyze-program-effect undead-out
                                                                                            effect)])
                                    (values undead-in (cons new-ust ust))))])

           ;(values pre-wrap-undead-out `(,pre-wrap-updated-ust))
           (values pre-wrap-undead-out pre-wrap-updated-ust)))]
      [`(if ,pred1 ,pred2 ,pred3)
       (let*-values ([(undead-out-pred3 ust-pred3) (analyze-program-pred undead-out pred3)]
                     [(undead-out-pred2 ust-pred2) (analyze-program-pred undead-out pred2)]
                     [(undead-out-pred1 ust-pred1)
                      (analyze-program-pred (set-union undead-out-pred3 undead-out-pred2) pred1)])
         (values undead-out-pred1 `(,ust-pred1 ,ust-pred2 ,ust-pred3)))]))

  ; undead-set (asm-lang-v2/locals triv) -> undead-set
  ; TAKEN FROM LECTURE
  ; adds triv to the undead-set if the triv is an aloc.
  (define (set-add-triv undead-set triv)
    (if (or (register? triv) (aloc? triv))
        (set-add undead-set triv)
        undead-set))

  ;; undead-set (asm-lang-v2/locals tail) -> (values undead-set ust)
  ;; takes in the undead-out set for the current instruction
  ;; and computes the undead-in set for the current instruction,
  ;; and the undead-set-tree for the effect
  (define (analyze-program-tail undead-out tail)
    (match tail
      [`(begin
          ,effects ...
          ,tail)
       (let-values ([(undead-out updated-ust) (analyze-program-tail undead-out tail)])
         (let-values ([(pre-wrap-undead-out pre-wrap-updated-ust)
                       (for/foldr ([undead-out undead-out] [ust updated-ust])
                                  ([effect effects])
                                  (let-values ([(undead-in new-ust) (analyze-program-effect undead-out
                                                                                            effect)])
                                    (values undead-in (cons new-ust ust))))])

           (values pre-wrap-undead-out `(,pre-wrap-updated-ust))
           ;(values pre-wrap-undead-out pre-wrap-updated-ust)
            ))]
      [`(halt ,triv)
       (let ([undead-in (set-add-triv undead-out triv)]) (values undead-in (cons undead-out '())))]
      [`(if ,pred ,tail1 ,tail2)
       (let*-values ([(undead-out-tail2 ust-tail2) (analyze-program-tail undead-out tail2)]
                     [(undead-out-tail1 ust-tail1) (analyze-program-tail undead-out tail1)]
                     [(undead-out-pred ust-pred)
                      (analyze-program-pred (set-union undead-out-tail1 undead-out-tail2) pred)])
         (values undead-out-pred `((,ust-pred ,(first ust-tail1) ,(first ust-tail2)))))]
      [`(jump ,label ,locs ...)
       (values (if (label? label)
                   locs
                   (cons label locs))
               (cons locs '()))]))

  (match p
    [`(module ,info ,definitions
        ...
        ,tail)
     `(module ,(info-set (info-set info
                                   'undead-out
                                   (let-values ([(_ ust) (analyze-program-tail `() tail)])
                                     (first ust)))
                         'call-undead
                         (set->list (unbox call-undead-box)))
              ,@(map analyze-definitions definitions)
        ,tail)]))

#;
(module+ test
  (require rackunit)
  (check-match (undead-analysis
  '(module
     ((new-frames ()) (locals (x.1 x.2 x.3)))
     (begin
       (set! x.1 (mref x.2 x.3))
       (mset! x.1 3 r15)
       (jump L.test.1 x.1))))
  `(module
  ((new-frames ())
   (locals (x.1 x.2 x.3))
   (call-undead ())
   (undead-out ((r15 x.1) (x.1) (x.1))))
  (begin (set! x.1 (mref x.2 x.3)) (mset! x.1 3 r15) (jump L.test.1 x.1))))

  (check-match (undead-analysis
  '(module
     ((new-frames ()) (locals (x.1 x.2 x.3 y.7)))
     (begin
       (set! x.1 5)
       (set! x.1 (mref x.2 x.3))
       (mset! x.1 y.7 r15)
       (jump L.test.1 x.1))))
  `(module
  ((new-frames ())
   (locals (x.1 x.2 x.3 y.7))
   (call-undead ())
   (undead-out ((x.3 x.2 r15 y.7) (r15 y.7 x.1) (x.1) (x.1))))
  (begin
    (set! x.1 5)
    (set! x.1 (mref x.2 x.3))
    (mset! x.1 y.7 r15)
    (jump L.test.1 x.1)))))

